const defaultPosts = [
  {id:1,user:"alex",avatar:"https://i.pravatar.cc/100?img=12",image:"https://picsum.photos/id/1015/800/800",caption:"My first post on Picly!",likes:12,liked:false,comments:[]},
  {id:2,user:"maya",avatar:"https://i.pravatar.cc/100?img=32",image:"https://picsum.photos/id/1016/800/800",caption:"A beautiful day ✨",likes:8,liked:false,comments:[]}
];

let posts = JSON.parse(localStorage.getItem("piclyPosts")) || defaultPosts;

function save(){localStorage.setItem("piclyPosts",JSON.stringify(posts));}

function renderStories(){
  const names=["alex","maya","rohan","sara","dev","riya","sam"];
  document.querySelector("#stories").innerHTML=names.map((n,i)=>`
    <div class="story"><img class="avatar" src="https://i.pravatar.cc/100?img=${12+i}"><div>${n}</div></div>
  `).join("");
}

function render(){
  document.querySelector("#feed").innerHTML=posts.map(p=>`
    <article class="post">
      <div class="post-head"><img src="${p.avatar}"><span>@${p.user}</span></div>
      <img class="post-image" src="${p.image}" alt="Post by ${p.user}">
      <div class="post-actions">
        <span class="like-btn ${p.liked?"liked":""}" onclick="toggleLike(${p.id})">♥</span>
        <span>💬</span>
        <span>↗</span>
      </div>
      <div class="caption"><b>${p.likes} likes</b><br>${escapeHtml(p.caption)}</div>
      <div class="comments">${p.comments.map(c=>`<div class="comment"><b>${escapeHtml(c.user)}</b> ${escapeHtml(c.text)}</div>`).join("")}</div>
      <form class="comment-box" onsubmit="addComment(event,${p.id})">
        <input name="comment" placeholder="Add a comment...">
        <button>Post</button>
      </form>
    </article>
  `).join("");
}

function toggleLike(id){
  const p=posts.find(x=>x.id===id);
  if(!p)return;
  p.liked=!p.liked;
  p.likes += p.liked ? 1 : -1;
  save(); render();
}

function addComment(e,id){
  e.preventDefault();
  const input=e.target.comment;
  const text=input.value.trim();
  if(!text)return;
  const p=posts.find(x=>x.id===id);
  p.comments.push({user:"alex",text});
  save(); render();
}

function escapeHtml(s){
  return s.replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[c]));
}

const modal=document.querySelector("#postModal");
document.querySelector("#newPostBtn").onclick=()=>modal.classList.remove("hidden");
document.querySelector("#cancelPost").onclick=()=>modal.classList.add("hidden");

document.querySelector("#publishPost").onclick=()=>{
  const image=document.querySelector("#imageUrl").value.trim();
  const caption=document.querySelector("#caption").value.trim();
  if(!image){alert("Please enter an image URL.");return;}
  posts.unshift({
    id:Date.now(),user:"alex",avatar:"https://i.pravatar.cc/100?img=12",
    image,caption,likes:0,liked:false,comments:[]
  });
  save(); render();
  document.querySelector("#imageUrl").value="";
  document.querySelector("#caption").value="";
  modal.classList.add("hidden");
};

renderStories();
render();
